sap.ui.define(["sap/fe/core/AppComponent"],function(e){"use strict";return e.extend("joulecapapp.JouleFioriApp.Component",{metadata:{manifest:"json"}})});
//# sourceMappingURL=Component.js.map